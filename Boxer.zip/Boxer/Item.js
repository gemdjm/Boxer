/// <reference path="data.js" />
/// <reference path="main.js" />

// Item object

function Item(n) {
	this.Number = n;
	this.Key = "i" + n;
	this.LsValue = localStorage.getItem(this.Key);
	this.Values = this.LsValue.split("|");
	this.ParentItemNumber = this.Values[0];
	this.Title = this.Values[1];
	this.ChildItemList = this.Values[2];
	this.Properties = this.Values[3];  // not used yet
	this.Text = this.Values[4];
	this.Html = "";

    // object methods
	this.BuildHtml = buildHtml;
	this.RefreshLsValue = RefreshLsValue;
	this.Save = saveItem;
    //this.ChangeTitle = changeItemTitle;
    //this.Focus = focused;
	//this.Blur = blurred;

	function buildHtml() {
	    //alert("buildHtml");
	    var addItemIcon = "<img src='addItem.png' title='Add Item within this Item' onclick='addItem(" + this.Number + ")' />";
	    var addRowIcon = "<img src='addRow.png' title='Add Text Row to this Item' onclick='addTextRow(" + this.Number + ")' />";
	    var itemIcons = "<span>" + addItemIcon + addRowIcon + "</span>";

	    var titleInput = "<input type='textbox' id='txtTitle" + this.Number
            + "' value='" + this.Title + "'"
            + " onblur='titleBlurred(" + this.Number + ")'"
            + " />";

	    var titleRow = itemIcons + "&nbsp;" + titleInput;

        //ensure at least 1 text row
	    if (this.Text == "")
	        this.Text = " ";
	    var textRowsHtml = "";
	    var textRows = this.Text.split("~");
	    for (var i=0; i<textRows.length; i++) {
	        var rowNumber = this.Number + "-" + i;
	        var textInputRow = makeTextRow(rowNumber, textRows[i]);
	        //alert("textRows[i]=" + textRows[i] + ", textInput=" + textInput);
	        textRowsHtml += textInputRow;
	    }

	    this.Html = "<div id='divItem" + this.Number + "' class='item'>"
            + "<div id='divTitle" + this.Number + "' class='caption'>" + titleRow + "</div>"
            + "<div id='divTextArea" + this.Number + "' >"
            //+ "<div id='divText" + this.Number + "' class='text'>" + textInput + "</div>"
            + textRowsHtml
            + "</div>"  // end of text area (item rows)
            + "<div id='divContainer" + this.Number + "' class='children'></div>";
	}

    function RefreshLsValue() {
        this.LsValue = 	this.ParentItemNumber + "|"
            + this.Title + "|"
            + this.ChildItemList + "|"
            + this.Properties + "|"
            + this.Text;
    }

    function saveItem() {
        //alert("this.Key=" + this.Key + ",  this.LsValue=" + this.LsValue);
	    localStorage.setItem(this.Key, this.LsValue);
    }

} // end of Item constructor


function makeTextRow(rowNumber, text) {
    // rowNumber e.g. "3-0"
    return "<div id='divText" + rowNumber + "' class='text'>"
        + "<input type='textbox' id='txtText" + rowNumber + "'"
        + " value='" + text + "'"
        + " onblur='textBlurred(" + rowNumber.replace("-", ",") + ")'"
        + " /></div>";
}

function changeItemTitle() {
    alert("changeItemTitle, this.Number=" + this.Number);  // not 
}

function focused() {
    alert("focused");  // test 
}

function titleBlurred(itemNo) {
    var activeItemTitleSelector = "#txtTitle" + itemNo; 
    var newTitle = $(activeItemTitleSelector).val();
    var changingItem = new Item(itemNo);
    if (changingItem.Title == newTitle)
        return;

    // use new title value to replace item's Title
    changingItem.Title = newTitle;
    changingItem.RefreshLsValue();
    changingItem.Save();        // to LS
}

function textBlurred(itemNo, rowNo) {
    var activeItemTextSelector = "#txtText" + itemNo + "-" + rowNo;
    var newText = $(activeItemTextSelector).val();

    if (!validText(newText))
        return;

    var changingItem = new Item(itemNo);
    var changingRows = changingItem.Text.split("~");
    if (changingRows[rowNo] == newText)
        return;

    changingRows[rowNo] = newText;
    // use new text value to replace item's Text
    changingItem.Text = changingRows.join("~");
    changingItem.RefreshLsValue();
    changingItem.Save();        // to LS
}

function validText(text) {
    var pos = text.indexOf("|");
    if (pos>-1) { alert("'|' not valid"); return false; }

    pos = text.indexOf("~");
    if (pos>-1) { alert("'~' not valid"); return false; }

    return true;
}

function addItem(parentItemNo) {
    //	Get MaxItemNumber, increment and re-save
    _maxItemNumber = localStorage.getItem("maxItemNumber");
    _maxItemNumber++;
    localStorage.setItem("maxItemNumber", _maxItemNumber);

    //	Create new empty item, with MaxItemNumber, append new item to active item
    var newItemNumber = _maxItemNumber;
    var newItemKey = "i" + newItemNumber;
    var newItemLsValue = parentItemNo + _newItemLsValueWithoutParentNumber;
    localStorage.setItem(newItemKey, newItemLsValue);

    displayItem(newItemNumber);

    // adjust parent's child list
    var parentItem = new Item(parentItemNo);
    var childList = parentItem.ChildItemList;
    var extendedChildList = (childList == "") ? newItemNumber : parentItem.ChildItemList + "," + newItemNumber;
    parentItem.ChildItemList = extendedChildList;
    parentItem.RefreshLsValue();
    parentItem.Save();
}

function addTextRow(itemNo) {
    var item = new Item(itemNo);
    var rows = item.Text.split("~");
    var maxRowIndex = rows.length;
    var nextRowIndex = maxRowIndex + 1;
    var newRowNumber = itemNo + "-" + nextRowIndex;
    //alert("item.Text=" + item.Text + ", nextRowIndex=" + nextRowIndex);

    // LS needs extended Text only, then save to LS & re-display
    item.Text = item.Text + "~";
    item.RefreshLsValue();

    //alert("item.LsValue=" + item.LsValue);
    localStorage.setItem("i" + itemNo, item.LsValue);

    item.Save();

    var newRowHtml = makeTextRow(newRowNumber, "");
    addRowToTextArea(itemNo, newRowHtml);
}

function addRowToTextArea(itemNo, rowHtml) {
    var holderId = "#divTextArea" + itemNo;
    //alert("addRowToTextArea, holderId=" + holderId + ", rowHtml=" + rowHtml); 
    $(holderId).append(rowHtml);
}