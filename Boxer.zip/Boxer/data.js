﻿
// items as in Local Storage: key, value, where value = parentItemNumber|titleText|childItemNumberList|properties|bodyText
// propties (e.g. flags) to be defined

var _startItemNumber = 1;

var _startupItems = [
    ["i1", "0|Boxer|2,3|..|text in Boxer~boxes in boxes"],
    ["i2", "1|Possible Names||..|Little Boxes~EdBox"],
    ["i3", "1|To Test|4|..|LS, Edit, Expand/Collapse"],
    ["i4", "3|Also||..|..."]
];

var _newItemLsValueWithoutParentNumber = "||||";