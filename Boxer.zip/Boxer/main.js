/// <reference path="data.js" />
/// <reference path="Item.js" />

var _maxItemNumber = 0;

$(document).ready(function () {
    if (!supports_html5_storage)
        return;
    ensureDataInLocalStorage();
    setupDisplay();
})

function supports_html5_storage() {
    try { return 'localStorage' in window && window['localStorage'] !== null; }
    catch (e) { return false; }
}

function ensureDataInLocalStorage() {
    // check if LS is available
    if (typeof (localStorage) == "undefined") {
        alert("No Local Storage");
        return false;
    }
    var firstItemNumber = localStorage.getItem("startItemNumber");
    var firstItemKey = localStorage.getItem("i" + firstItemNumber);
 
    if (firstItemNumber == null || firstItemKey == null)
        copyStarterDataToLocalStorage();
    return true;
}

function copyStarterDataToLocalStorage() {
    alert("copying Start-up data To Local Storage - once only");
    localStorage.setItem("startItemNumber", _startItemNumber);
    for (var i=0; i<_startupItems.length; i++) {
        var itemInfo = _startupItems[i];
        var itemKey = itemInfo[0];
        var itemValue = itemInfo[1];
        localStorage.setItem(itemKey, itemValue);
    }
    //alert("end of copyStarterDataToLocalStorage, localStorage.length=" + localStorage.length);
}

function setupDisplay() {
    var startItemNumber = localStorage.getItem("startItemNumber");
    displayItem(startItemNumber); // recursive
    var storedMaxItemNumber = localStorage.getItem("maxItemNumber");
    if (storedMaxItemNumber == null) {
        alert("maxItemNumber to LS: " + _maxItemNumber);
        localStorage.setItem("maxItemNumber", _maxItemNumber);
    }
    //else
    //    alert("maxItemNumber in LS: " + storedMaxItemNumber);
}

function displayItem(itemNumber) {
    //alert("displayItem, itemNumber=" + itemNumber);
    if (itemNumber > _maxItemNumber)
        _maxItemNumber = itemNumber;
    var key = "i" + itemNumber;
    //var item1 = localStorage.getItem(key);

    var item = new Item(itemNumber);
    if (item == null) { alert("item " + key + " not found"); return 0; }

    // 1-off fix
    //if (item.Title == "TO GO" && item.Text.indexOf("<div")>-1) {
    //    alert("to go: " + itemNumber + ", Text=" + item.Text);
    //    item.Text = "gone";
    //    item.RefreshLsValue();
    //    item.Save();
    //}

    item.BuildHtml();
    //alert("item.Html=" + item.Html);

    var parentSelector = "#divContainer" + item.ParentItemNumber;
    $(parentSelector).append(item.Html);
    //alert("parentSelector.Html=" + $(parentSelector).html());

    if (item.ChildItemList != "") {
        var childItems = item.ChildItemList.split(",");
        for (var i = 0; i < childItems.length; i++) {
            displayItem(childItems[i]);
        }
    }
}